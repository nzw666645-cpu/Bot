#!/bin/bash

# Script de inicialização do bot Discord

echo "=========================================="
echo "   Iniciando Bot Discord"
echo "=========================================="

# Verificar se o ambiente virtual existe
if [ ! -d "venv" ]; then
    echo "[INFO] Criando ambiente virtual..."
    python3.11 -m venv venv
    
    echo "[INFO] Instalando dependências..."
    source venv/bin/activate
    pip install -q discord.py aiohttp
else
    echo "[INFO] Ambiente virtual encontrado!"
    source venv/bin/activate
fi

echo "[INFO] Iniciando bot..."
echo ""

# Executar o bot
python main.py
