import discord
from discord.ext import commands
import os
import sys
import asyncio
from datetime import datetime
import importlib.util

# Token do bot
TOKEN = "MTQ1NTY3ODA3MDkzNjcwMzAxNw.GdXxOD.oy5lBN4RhHYKi1N-yp4THOEM5MFbYLUnhAmZCA"

# Configuração de intents
intents = discord.Intents.all()

# Criação do bot
bot = commands.Bot(command_prefix="!", intents=intents)

# Variáveis globais para estatísticas
bot.start_time = None
bot.command_usage = {}

# Função para carregar comandos da pasta 'commands'
async def load_commands():
    commands_dir = os.path.join(os.path.dirname(__file__), 'commands')
    
    if not os.path.exists(commands_dir):
        print(f"[ERRO] Pasta de comandos não encontrada: {commands_dir}")
        return
    
    loaded_count = 0
    failed_count = 0
    
    print("\n" + "="*60)
    print("CARREGANDO COMANDOS".center(60))
    print("="*60)
    
    for filename in os.listdir(commands_dir):
        if filename.endswith('.py') and not filename.startswith('_'):
            command_name = filename[:-3]
            file_path = os.path.join(commands_dir, filename)
            
            try:
                # Carregar o módulo dinamicamente
                spec = importlib.util.spec_from_file_location(command_name, file_path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                
                # Verificar se tem a função setup
                if hasattr(module, 'setup'):
                    await module.setup(bot)
                    loaded_count += 1
                    print(f"✓ Comando carregado: {command_name}")
                else:
                    failed_count += 1
                    print(f"✗ Erro: {command_name} não possui função setup()")
                    
            except Exception as e:
                failed_count += 1
                print(f"✗ Erro ao carregar {command_name}: {str(e)}")
    
    print("="*60)
    print(f"Total: {loaded_count} carregados | {failed_count} falharam")
    print("="*60 + "\n")

# Evento de inicialização
@bot.event
async def on_ready():
    bot.start_time = datetime.now()
    
    print("\n" + "="*60)
    print("BOT DISCORD INICIADO".center(60))
    print("="*60)
    print(f"Nome do Bot: {bot.user.name}")
    print(f"ID do Bot: {bot.user.id}")
    print(f"Discriminador: #{bot.user.discriminator}")
    print(f"Data/Hora: {bot.start_time.strftime('%d/%m/%Y %H:%M:%S')}")
    print("="*60)
    
    # Estatísticas de servidores
    total_guilds = len(bot.guilds)
    total_members = sum(guild.member_count for guild in bot.guilds)
    online_members = sum(1 for guild in bot.guilds for member in guild.members if member.status != discord.Status.offline)
    
    print("\nESTATÍSTICAS DO BOT".center(60))
    print("="*60)
    print(f"Servidores: {total_guilds}")
    print(f"Usuários Totais: {total_members}")
    print(f"Usuários Online: {online_members}")
    print(f"Usuários Offline: {total_members - online_members}")
    print("="*60)
    
    # Lista de servidores
    if total_guilds > 0:
        print("\nSERVIDORES CONECTADOS".center(60))
        print("="*60)
        for guild in bot.guilds:
            owner = guild.owner
            print(f"• {guild.name}")
            print(f"  ID: {guild.id}")
            print(f"  Dono: {owner.name if owner else 'Desconhecido'}")
            print(f"  Membros: {guild.member_count}")
            print(f"  Criado em: {guild.created_at.strftime('%d/%m/%Y')}")
            print("-"*60)
        print("="*60)
    
    # Carregar comandos
    await load_commands()
    
    # Sincronizar comandos slash
    try:
        print("\n[INFO] Sincronizando comandos slash...")
        synced = await bot.tree.sync()
        print(f"[SUCESSO] {len(synced)} comandos slash sincronizados!")
    except Exception as e:
        print(f"[ERRO] Falha ao sincronizar comandos: {e}")
    
    # Definir status do bot
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name=f"{total_guilds} servidores | {total_members} usuários"
        ),
        status=discord.Status.online
    )
    
    print("\n[BOT PRONTO] Aguardando comandos...\n")

# Evento quando o bot entra em um servidor
@bot.event
async def on_guild_join(guild):
    print("\n" + "="*60)
    print("NOVO SERVIDOR ADICIONADO".center(60))
    print("="*60)
    print(f"Nome: {guild.name}")
    print(f"ID: {guild.id}")
    print(f"Membros: {guild.member_count}")
    print(f"Dono: {guild.owner.name if guild.owner else 'Desconhecido'}")
    print("="*60 + "\n")
    
    # Atualizar status
    total_guilds = len(bot.guilds)
    total_members = sum(guild.member_count for guild in bot.guilds)
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name=f"{total_guilds} servidores | {total_members} usuários"
        )
    )

# Evento quando o bot sai de um servidor
@bot.event
async def on_guild_remove(guild):
    print("\n" + "="*60)
    print("REMOVIDO DE UM SERVIDOR".center(60))
    print("="*60)
    print(f"Nome: {guild.name}")
    print(f"ID: {guild.id}")
    print("="*60 + "\n")
    
    # Atualizar status
    total_guilds = len(bot.guilds)
    total_members = sum(guild.member_count for guild in bot.guilds)
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name=f"{total_guilds} servidores | {total_members} usuários"
        )
    )

# Evento de uso de comandos
@bot.event
async def on_interaction(interaction: discord.Interaction):
    if interaction.type == discord.InteractionType.application_command:
        command_name = interaction.command.name if interaction.command else "desconhecido"
        
        # Registrar uso do comando
        if command_name not in bot.command_usage:
            bot.command_usage[command_name] = 0
        bot.command_usage[command_name] += 1
        
        # Informações do usuário
        user = interaction.user
        guild = interaction.guild
        
        print("\n" + "="*60)
        print("COMANDO EXECUTADO".center(60))
        print("="*60)
        print(f"Comando: /{command_name}")
        print(f"Usuário: {user.name}#{user.discriminator} (ID: {user.id})")
        print(f"Servidor: {guild.name if guild else 'DM'} (ID: {guild.id if guild else 'N/A'})")
        print(f"Canal: {interaction.channel.name if hasattr(interaction.channel, 'name') else 'DM'}")
        print(f"Data/Hora: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        print(f"Total de usos deste comando: {bot.command_usage[command_name]}")
        print("="*60 + "\n")

# Tratamento de erros
@bot.event
async def on_command_error(ctx, error):
    print(f"\n[ERRO] {error}\n")

# Iniciar o bot
if __name__ == "__main__":
    try:
        print("\n[INFO] Iniciando bot Discord...")
        bot.run(TOKEN)
    except KeyboardInterrupt:
        print("\n[INFO] Bot encerrado pelo usuário.")
    except Exception as e:
        print(f"\n[ERRO FATAL] {e}")
        sys.exit(1)
