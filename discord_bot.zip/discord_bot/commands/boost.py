import discord
from discord import app_commands
from discord.ext import commands
import json
import os
from datetime import datetime

# Caminho para o arquivo de configuração e pasta de imagens
CONFIG_PATH = "boost_config.json"
IMAGE_DIR = "assets/boost"

if not os.path.exists(IMAGE_DIR):
    os.makedirs(IMAGE_DIR)

def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "roles": {},
        "ad_text": ": ** # APOIE NOSSO SERVIDOR!**\n\nAo dar um Boost em nosso servidor, você ganha cargos exclusivos e tendo acesso canais de estudos e grupo privado do nosso servidor !\n\n:e**Vantagens:**\n• Cargos com Permissões e acesso a canais exclusivos\n• 🚀 Participe da Nossa TEAM:Boosters têm prioridade para participar da Team Oficial do servidor, colaborando em projetos e tendo voz ativa nas decisões da nossa equipe.✅ Acesso aos Canais de Studio: Estude com os melhores! Canais fechados com conteúdo de alto nível.✅ Vaga na Team: Participe ativamente da nossa organização e projetos internos.✅ Cargos de Elite: Cargos exclusivos baseados na quantidade de boosts.✅ DM Prioritária: Fale diretamente com a administração com prioridade.💎 Como ajudar? Basta clicar no nome do servidor e selecionar 'Impulso de Servidor'. Sua ajuda faz toda a diferença! servidor\n\nAjude-nos a crescer!",
        "ad_image_path": None,
        "dm_message": "Olá {user}! Muito obrigado por dar um Boost no servidor **{guild}**! 🚀\nVocê acaba de receber o cargo **{role}** como recompensa. Aproveite seus benefícios.!"
    }

def save_config(config):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4, ensure_ascii=False)

class BoostSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config = load_config()

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.premium_since is None and after.premium_since is not None:
            guild = after.guild
            user = after
            boost_roles = self.config.get("roles", {})
            role_id = boost_roles.get("1")
            if role_id:
                role = guild.get_role(int(role_id))
                if role:
                    try:
                        await user.add_roles(role)
                        dm_text = self.config.get("dm_message").format(
                            user=user.name,
                            guild=guild.name,
                            role=role.name
                        )
                        try:
                            await user.send(dm_text)
                        except:
                            pass
                    except Exception as e:
                        print(f"[ERRO] Falha ao adicionar cargo de boost: {e}")

    @app_commands.command(name="boost_setup", description="Configura o sistema de recompensas por Boost")
    @app_commands.describe(
        acao="O que você deseja configurar",
        valor="O valor (ID do cargo, Texto ou Mensagem DM)",
        imagem="Anexe o arquivo de imagem para a propaganda"
    )
    @app_commands.choices(acao=[
        app_commands.Choice(name="Definir Cargo (1 Boost)", value="role_1"),
        app_commands.Choice(name="Definir Cargo (2 Boosts)", value="role_2"),
        app_commands.Choice(name="Editar Texto de Propaganda", value="text"),
        app_commands.Choice(name="Definir Imagem de Propaganda (ARQUIVO)", value="image"),
        app_commands.Choice(name="Editar Mensagem da DM", value="dm")
    ])
    async def boost_setup(
        self, 
        interaction: discord.Interaction, 
        acao: str, 
        valor: str = None, 
        imagem: discord.Attachment = None
    ):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Apenas administradores podem usar este comando.", ephemeral=True)

        if acao == "image":
            if not imagem:
                return await interaction.response.send_message("❌ Por favor, anexe um arquivo de imagem ao usar esta opção.", ephemeral=True)
            
            # Salvar a imagem localmente
            file_extension = imagem.filename.split(".")[-1]
            file_path = os.path.join(IMAGE_DIR, f"ad_image.{file_extension}")
            await imagem.save(file_path)
            
            self.config["ad_image_path"] = file_path
            save_config(self.config)
            await interaction.response.send_message(f"✅ Imagem de propaganda salva com sucesso: `{imagem.filename}`", ephemeral=True)
            return

        if not valor:
            return await interaction.response.send_message("❌ Você precisa fornecer um valor para esta ação.", ephemeral=True)

        if acao.startswith("role_"):
            level = acao.split("_")[1]
            role_id = valor.replace("<@&", "").replace(">", "")
            try:
                role = interaction.guild.get_role(int(role_id))
                if not role:
                    return await interaction.response.send_message("❌ Cargo não encontrado.", ephemeral=True)
                self.config["roles"][level] = str(role.id)
                save_config(self.config)
                await interaction.response.send_message(f"✅ Cargo para **{level} Boost(s)** definido: {role.mention}", ephemeral=True)
            except:
                await interaction.response.send_message("❌ ID de cargo inválido.", ephemeral=True)

        elif acao == "text":
            self.config["ad_text"] = valor
            save_config(self.config)
            await interaction.response.send_message("✅ Texto de propaganda atualizado!", ephemeral=True)

        elif acao == "dm":
            self.config["dm_message"] = valor
            save_config(self.config)
            await interaction.response.send_message("✅ Mensagem de DM atualizada!", ephemeral=True)

    @app_commands.command(name="boost_anuncio", description="Envia o anúncio de recompensas por Boost")
    async def boost_anuncio(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Apenas administradores podem usar este comando.", ephemeral=True)

        embed = discord.Embed(
            title="💎 Sistema de Recompensas por Boost",
            description=self.config["ad_text"],
            color=discord.Color.from_rgb(255, 115, 250),
            timestamp=datetime.now()
        )
        
        roles_text = ""
        for level, role_id in self.config["roles"].items():
            role = interaction.guild.get_role(int(role_id))
            if role:
                roles_text += f"✨ **{level} Boost(s):** {role.mention}\n"
        
        if roles_text:
            embed.add_field(name="🏆 Cargos Disponíveis", value=roles_text, inline=False)

        file = None
        if self.config["ad_image_path"] and os.path.exists(self.config["ad_image_path"]):
            file = discord.File(self.config["ad_image_path"], filename="boost_ad.png")
            embed.set_image(url="attachment://boost_ad.png")
        
        embed.set_footer(text="Obrigado por apoiar nossa comunidade!")
        
        if file:
            await interaction.channel.send(file=file, embed=embed)
        else:
            await interaction.channel.send(embed=embed)
            
        await interaction.response.send_message("✅ Anúncio enviado com sucesso!", ephemeral=True)

async def setup(bot):
    await bot.add_cog(BoostSystem(bot))
    print(f"[COMANDO] boost.py (Versão Arquivo Local) carregado com sucesso!")
