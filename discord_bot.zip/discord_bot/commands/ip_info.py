import discord
from discord import app_commands
from datetime import datetime
import aiohttp
import socket

async def get_ip_info(ip: str):
    """Obtém informações detalhadas sobre um IP usando múltiplas APIs"""
    info = {
        "ip": ip,
        "tipo": "Não informado",
        "classe": "Não informado",
        "hostname": "Não informado",
        "pais": "Não informado",
        "regiao": "Não informado",
        "cidade": "Não informado",
        "latitude": "Não informado",
        "longitude": "Não informado",
        "isp": "Não informado",
        "organizacao": "Não informado",
        "asn": "Não informado",
        "proxy": "Não detectado",
        "vpn": "Não detectado",
        "tor": "Não detectado",
        "hosting": "Não detectado",
        "timezone": "Não informado",
        "portas_comuns": "Não verificado",
        "dns_reverso": "Não informado"
    }
    
    try:
        # Tentar obter hostname
        try:
            hostname = socket.gethostbyaddr(ip)
            info["hostname"] = hostname[0] if hostname else "Não informado"
        except:
            pass
        
        # Tentar DNS reverso
        try:
            dns_reverse = socket.getfqdn(ip)
            if dns_reverse != ip:
                info["dns_reverso"] = dns_reverse
        except:
            pass
        
        # Determinar classe do IP
        first_octet = int(ip.split('.')[0])
        if 1 <= first_octet <= 126:
            info["classe"] = "Classe A"
        elif 128 <= first_octet <= 191:
            info["classe"] = "Classe B"
        elif 192 <= first_octet <= 223:
            info["classe"] = "Classe C"
        elif 224 <= first_octet <= 239:
            info["classe"] = "Classe D (Multicast)"
        elif 240 <= first_octet <= 255:
            info["classe"] = "Classe E (Experimental)"
        
        # Determinar tipo de IP
        if ip.startswith("10.") or ip.startswith("192.168.") or ip.startswith("172."):
            info["tipo"] = "IP Privado"
        else:
            info["tipo"] = "IP Público"
        
        # API 1: ip-api.com (informações geográficas e ISP)
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(f"http://ip-api.com/json/{ip}?fields=status,message,country,regionName,city,lat,lon,timezone,isp,org,as,proxy,hosting") as response:
                    if response.status == 200:
                        data = await response.json()
                        if data.get("status") == "success":
                            info["pais"] = data.get("country", "Não informado")
                            info["regiao"] = data.get("regionName", "Não informado")
                            info["cidade"] = data.get("city", "Não informado")
                            info["latitude"] = str(data.get("lat", "Não informado"))
                            info["longitude"] = str(data.get("lon", "Não informado"))
                            info["timezone"] = data.get("timezone", "Não informado")
                            info["isp"] = data.get("isp", "Não informado")
                            info["organizacao"] = data.get("org", "Não informado")
                            info["asn"] = data.get("as", "Não informado")
                            info["proxy"] = "Detectado" if data.get("proxy", False) else "Não detectado"
                            info["hosting"] = "Detectado" if data.get("hosting", False) else "Não detectado"
            except:
                pass
            
            # API 2: ipapi.co (informações adicionais)
            try:
                async with session.get(f"https://ipapi.co/{ip}/json/") as response:
                    if response.status == 200:
                        data = await response.json()
                        if not data.get("error"):
                            # Complementar informações se não foram obtidas
                            if info["pais"] == "Não informado":
                                info["pais"] = data.get("country_name", "Não informado")
                            if info["regiao"] == "Não informado":
                                info["regiao"] = data.get("region", "Não informado")
                            if info["cidade"] == "Não informado":
                                info["cidade"] = data.get("city", "Não informado")
                            if info["latitude"] == "Não informado":
                                info["latitude"] = str(data.get("latitude", "Não informado"))
                            if info["longitude"] == "Não informado":
                                info["longitude"] = str(data.get("longitude", "Não informado"))
            except:
                pass
            
            # API 3: ipqualityscore.com (detecção de VPN/Proxy) - versão gratuita
            try:
                async with session.get(f"https://www.ipqualityscore.com/api/json/ip/DEMO/{ip}") as response:
                    if response.status == 200:
                        data = await response.json()
                        if data.get("success"):
                            if data.get("vpn"):
                                info["vpn"] = "Detectado"
                            if data.get("tor"):
                                info["tor"] = "Detectado"
                            if data.get("proxy") and info["proxy"] == "Não detectado":
                                info["proxy"] = "Detectado"
            except:
                pass
    
    except Exception as e:
        print(f"[ERRO] Erro ao obter informações do IP: {e}")
    
    return info

async def setup(bot):
    @bot.tree.command(name="ip_info", description="Mostra informações detalhadas sobre um endereço IP")
    @app_commands.describe(ip="Endereço IP para consultar (ex: 8.8.8.8)")
    async def ip_info(interaction: discord.Interaction, ip: str):
        # Validação básica de IP
        parts = ip.split('.')
        if len(parts) != 4 or not all(part.isdigit() and 0 <= int(part) <= 255 for part in parts):
            await interaction.response.send_message("❌ Endereço IP inválido! Use o formato: xxx.xxx.xxx.xxx", ephemeral=True)
            return
        
        # Defer a resposta pois pode demorar
        await interaction.response.defer()
        
        # Obter informações do IP
        info = await get_ip_info(ip)
        
        # Criar embed principal
        embed = discord.Embed(
            title=f"🌐 Informações do IP: {ip}",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        # Informações básicas
        embed.add_field(
            name="📋 Informações Básicas",
            value=f"**IP:** {info['ip']}\n"
                  f"**Tipo:** {info['tipo']}\n"
                  f"**Classe:** {info['classe']}\n"
                  f"**Hostname:** {info['hostname']}\n"
                  f"**DNS Reverso:** {info['dns_reverso']}",
            inline=False
        )
        
        # Localização
        maps_link = "Não disponível"
        if info['latitude'] != "Não informado" and info['longitude'] != "Não informado":
            maps_link = f"[Ver no Google Maps](https://www.google.com/maps?q={info['latitude']},{info['longitude']})"
        
        embed.add_field(
            name="📍 Localização",
            value=f"**País:** {info['pais']}\n"
                  f"**Região:** {info['regiao']}\n"
                  f"**Cidade:** {info['cidade']}\n"
                  f"**Latitude:** {info['latitude']}\n"
                  f"**Longitude:** {info['longitude']}\n"
                  f"**Timezone:** {info['timezone']}\n"
                  f"**Mapa:** {maps_link}",
            inline=False
        )
        
        # Rede e ISP
        embed.add_field(
            name="🌐 Rede e ISP",
            value=f"**ISP:** {info['isp']}\n"
                  f"**Organização:** {info['organizacao']}\n"
                  f"**ASN:** {info['asn']}",
            inline=False
        )
        
        # Segurança e Detecção
        proxy_emoji = "🔴" if info['proxy'] == "Detectado" else "🟢"
        vpn_emoji = "🔴" if info['vpn'] == "Detectado" else "🟢"
        tor_emoji = "🔴" if info['tor'] == "Detectado" else "🟢"
        hosting_emoji = "🔴" if info['hosting'] == "Detectado" else "🟢"
        
        embed.add_field(
            name="🔒 Segurança e Detecção",
            value=f"{proxy_emoji} **Proxy:** {info['proxy']}\n"
                  f"{vpn_emoji} **VPN:** {info['vpn']}\n"
                  f"{tor_emoji} **TOR:** {info['tor']}\n"
                  f"{hosting_emoji} **Hosting:** {info['hosting']}",
            inline=False
        )
        
        # Aviso sobre precisão
        embed.set_footer(
            text=f"⚠️ As informações de localização podem não ser exatas | Solicitado por {interaction.user.name}",
            icon_url=interaction.user.display_avatar.url
        )
        
        await interaction.followup.send(embed=embed)
    
    print(f"[COMANDO] ip_info.py carregado com sucesso!")
