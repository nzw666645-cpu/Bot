import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
import asyncio
import io
import os

# ================= CONFIGURAÇÕES GLOBAIS =================
TICKET_CATEGORY_NAME = "TICKETS"
LOG_CHANNEL_NAME = "logs-tickets"
SUPPORT_ROLE_NAME = "Suporte"
MAX_TICKETS_PER_USER = 1
TICKET_ASSETS_DIR = "assets/tickets"

if not os.path.exists(TICKET_ASSETS_DIR):
    os.makedirs(TICKET_ASSETS_DIR)

# ================= UTILITÁRIOS =================

async def create_transcript(channel):
    transcript = f"--- TRANSCRIÇÃO DO TICKET: {channel.name} ---\n"
    transcript += f"Data de Fechamento: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n"
    messages = []
    async for message in channel.history(limit=None, oldest_first=True):
        time = message.created_at.strftime('%H:%M:%S')
        content = message.content if message.content else "[Arquivo/Embed]"
        messages.append(f"[{time}] {message.author.name}: {content}")
    transcript += "\n".join(messages)
    return transcript

# ================= VIEWS E COMPONENTES =================

class TicketSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Suporte Técnico", description="Problemas técnicos e assistência", emoji="🛠️", value="suporte_tecnico"),
            discord.SelectOption(label="Denúncia", description="Reportar usuários ou problemas", emoji="🚫", value="denuncia"),
            discord.SelectOption(label="Dúvidas", description="Perguntas sobre serviços", emoji="❓", value="duvidas"),
            discord.SelectOption(label="Parcerias", description="Propostas de colaboração", emoji="🤝", value="parcerias"),
            discord.SelectOption(label="Outros", description="Assuntos não categorizados", emoji="📁", value="outros"),
        ]
        super().__init__(placeholder="Selecione a categoria do atendimento", min_values=1, max_values=1, options=options, custom_id="ticket_select_main")

    async def callback(self, interaction: discord.Interaction):
        guild = interaction.guild
        user = interaction.user
        category_value = self.values[0]
        category_label = [o.label for o in self.options if o.value == category_value][0]

        category = discord.utils.get(guild.categories, name=TICKET_CATEGORY_NAME)
        if category:
            existing_ticket = discord.utils.get(category.text_channels, topic=f"ID:{user.id}")
            if existing_ticket:
                return await interaction.response.send_message(f"❌ Você já possui um ticket aberto: {existing_ticket.mention}", ephemeral=True)
        else:
            category = await guild.create_category(TICKET_CATEGORY_NAME)

        await interaction.response.defer(ephemeral=True)

        support_role = discord.utils.get(guild.roles, name=SUPPORT_ROLE_NAME)
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            user: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True, embed_links=True),
            guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True)
        }
        if support_role:
            overwrites[support_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_messages=True)

        channel_name = f"🎫-{user.name}-{category_value}"
        channel = await guild.create_text_channel(name=channel_name, category=category, overwrites=overwrites, topic=f"ID:{user.id}")

        embed = discord.Embed(
            title=f"🎫 Atendimento: {category_label}",
            description=f"Olá {user.mention}, bem-vindo ao seu ticket!\nNossa equipe de suporte foi notificada e entrará em contato em breve.\n\n"
                        f"**Informações:**\n"
                        f"👤 **Usuário:** {user.name} (ID: {user.id})\n"
                        f"📂 **Categoria:** {category_label}\n"
                        f"⏰ **Aberto em:** {datetime.now().strftime('%d/%m/%Y %H:%M')}",
            color=discord.Color.blue()
        )
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_footer(text="Use os botões abaixo para gerenciar o ticket.")

        view = TicketControlView()
        await channel.send(content=f"{user.mention} | {support_role.mention if support_role else ''}", embed=embed, view=view)
        
        log_channel = discord.utils.get(guild.text_channels, name=LOG_CHANNEL_NAME)
        if log_channel:
            log_embed = discord.Embed(
                title="🟢 Ticket Aberto",
                description=f"**Usuário:** {user.mention} ({user.id})\n**Canal:** {channel.mention}\n**Categoria:** {category_label}",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            await log_channel.send(embed=log_embed)

        await interaction.followup.send(f"✅ Seu ticket foi criado: {channel.mention}", ephemeral=True)

class TicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Fechar", style=discord.ButtonStyle.red, emoji="🔒", custom_id="btn_close_ticket")
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        is_support = any(role.name == SUPPORT_ROLE_NAME for role in interaction.user.roles)
        is_owner = interaction.channel.topic == f"ID:{interaction.user.id}"
        if not (is_support or is_owner or interaction.user.guild_permissions.administrator):
            return await interaction.response.send_message("❌ Você não tem permissão para fechar este ticket.", ephemeral=True)
        confirm_view = ConfirmCloseView()
        await interaction.response.send_message("⚠️ Tem certeza que deseja fechar este ticket?", view=confirm_view, ephemeral=True)

    @discord.ui.button(label="Reivindicar", style=discord.ButtonStyle.green, emoji="🙋‍♂️", custom_id="btn_claim_ticket")
    async def claim(self, interaction: discord.Interaction, button: discord.ui.Button):
        is_support = any(role.name == SUPPORT_ROLE_NAME for role in interaction.user.roles)
        if not (is_support or interaction.user.guild_permissions.administrator):
            return await interaction.response.send_message("❌ Apenas a equipe de suporte pode reivindicar tickets.", ephemeral=True)
        button.disabled = True
        button.label = f"Reivindicado por {interaction.user.name}"
        button.style = discord.ButtonStyle.gray
        embed = interaction.message.embeds[0]
        embed.add_field(name="🙋‍♂️ Atendente", value=interaction.user.mention, inline=False)
        await interaction.response.edit_message(embed=embed, view=self)
        await interaction.followup.send(f"✅ Este ticket agora está sendo atendido por {interaction.user.mention}.")

class ConfirmCloseView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=30)

    @discord.ui.button(label="Confirmar Fechamento", style=discord.ButtonStyle.danger, custom_id="confirm_close")
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("🔒 Fechando ticket e gerando transcrição...")
        channel = interaction.channel
        guild = interaction.guild
        transcript_text = await create_transcript(channel)
        file = discord.File(io.BytesIO(transcript_text.encode()), filename=f"transcript-{channel.name}.txt")
        log_channel = discord.utils.get(guild.text_channels, name=LOG_CHANNEL_NAME)
        if log_channel:
            log_embed = discord.Embed(title="🔴 Ticket Fechado", description=f"**Canal:** {channel.name}\n**Fechado por:** {interaction.user.mention}", color=discord.Color.red(), timestamp=datetime.now())
            await log_channel.send(embed=log_embed, file=file)
        await asyncio.sleep(5)
        await channel.delete()

class TicketMainView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketSelect())

# ================= COMANDOS =================

async def setup(bot):
    @bot.tree.command(name="ticket_setup", description="Configura o sistema de tickets com imagem local e texto longo")
    @app_commands.describe(
        titulo="Título do painel de tickets",
        descricao="Descrição detalhada do painel de tickets (suporta textos longos)",
        imagem="Anexe o arquivo de imagem para o painel"
    )
    async def ticket_setup(
        interaction: discord.Interaction, 
        titulo: str = "Central de Atendimento", 
        descricao: str = "Precisa de ajuda? Selecione a categoria abaixo para abrir um ticket e falar com nossa equipe.",
        imagem: discord.Attachment = None
    ):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Apenas administradores podem usar este comando.", ephemeral=True)

        await interaction.response.defer(ephemeral=True)

        embed = discord.Embed(
            title=f"✨ {titulo}",
            description=descricao,
            color=discord.Color.blue()
        )
        
        # Salvar imagem se fornecida
        file = None
        if imagem:
            file_extension = imagem.filename.split(".")[-1]
            file_path = os.path.join(TICKET_ASSETS_DIR, f"ticket_panel.{file_extension}")
            await imagem.save(file_path)
            file = discord.File(file_path, filename="ticket_panel.png")
            embed.set_image(url="attachment://ticket_panel.png")
        
        embed.set_footer(text="Sistema de Atendimento Profissional")
        
        view = TicketMainView()
        if file:
            await interaction.channel.send(file=file, embed=embed, view=view)
        else:
            await interaction.channel.send(embed=embed, view=view)
        
        # Criar canal de logs se não existir
        log_channel = discord.utils.get(interaction.guild.text_channels, name=LOG_CHANNEL_NAME)
        if not log_channel:
            overwrites = {
                interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                interaction.guild.me: discord.PermissionOverwrite(read_messages=True)
            }
            await interaction.guild.create_text_channel(name=LOG_CHANNEL_NAME, overwrites=overwrites)

        await interaction.followup.send("✅ Sistema de tickets configurado com sucesso!", ephemeral=True)

    print(f"[COMANDO] ticket.py (Versão Imagem Local) carregado com sucesso!")
